package data.missions.SCVE_Mods;

import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.Comparator_Utils.PRIORITY_SHIP;
import static data.scripts.SCVE_Utils.getBaseHullSpecs;
import static data.scripts.SCVE_Utils.createFleetMembersFromBaseHulls;
import static data.scripts.SCVE_Utils.getCommonPrefixRegex;
import static data.scripts.SCVE_Utils.createFleetMembersFromModSkins;
import static data.scripts.Comparator_Utils.getTechTypesByFrequency;
import static data.scripts.Comparator_Utils.modTechTypeByFrequency;
import static data.scripts.Filter_Rules.getHullmodFilter;
import static data.scripts.Filter_Rules.getSpoilerFilter;
import static data.scripts.Filter_Rules.getWeaponWingFilter;
import static data.scripts.Hullmod_Utils.getHullmodsFromMod;
import static data.scripts.SCVE_Utils.HULLMOD_RULE;
import static data.scripts.SCVE_Utils.MODS_WITH_SHIPS_LIST;
import static data.scripts.SCVE_Utils.MODULES_LIST;
import static data.scripts.SCVE_Utils.SPOILER_RULE;
import static data.scripts.SCVE_Utils.VANILLA_SHIP_ID_LIST;
import static data.scripts.SCVE_Utils.WEAPON_WING_RULE;
import static data.scripts.SCVE_Utils.getFactionsFromMod;
import static data.scripts.SCVE_Utils.getModsWithShips;
import static data.scripts.SCVE_Utils.initializeMissions;
import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class MissionDefinition implements MissionDefinitionPlugin {

    public static int MIN_FOR_COMMON = 2, currentSelection;
    public static String MOD_ID, MOD_NAME;
    public static boolean firstLoad = true;

    public static Logger log = Global.getLogger(MissionDefinition.class);

    //returns modsWithShips
    public void getCurrentMod() {
        if (firstLoad) {
            currentSelection = 0;
            firstLoad = false;
        } else if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
            currentSelection++;
            if (currentSelection >= MODS_WITH_SHIPS_LIST.size()) {
                currentSelection = 0;
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
            currentSelection--;
            if (currentSelection < 0) {
                currentSelection = MODS_WITH_SHIPS_LIST.size() - 1;
            }
        }

        if (!MODS_WITH_SHIPS_LIST.isEmpty()) {
            MOD_ID = MODS_WITH_SHIPS_LIST.get(currentSelection);
            MOD_NAME = Global.getSettings().getModManager().getModSpec(MOD_ID).getName();
            modTechTypeByFrequency = getTechTypesByFrequency(MOD_ID);
            log.info("Current mod: " + MOD_NAME);
        } else {
            log.info("No mods are adding ships.");
            MOD_ID = "";
            MOD_NAME = "";
        }
    }

    @Override
    public void defineMission(MissionDefinitionAPI api) {

        initializeMissions(api);

        getCurrentMod();

        Set<FleetMemberAPI> ships = new TreeSet<>(PRIORITY_SHIP);

        if (MOD_NAME.isEmpty()) {
            log.info("ERROR: NO APPLICABLE MOD ENABLED");
            api.setFleetTagline(FleetSide.PLAYER, "ERROR: NO APPLICABLE MOD ENABLED");
            api.addToFleet(FleetSide.PLAYER, "nebula_Hull", FleetMemberType.SHIP, "ERROR", false);
            //api.addToFleet(FleetSide.PLAYER, "scve_venture_Hamatsu", FleetMemberType.SHIP, "ZIG Hamatsu", true);

            api.addBriefingItem("ERROR: NO APPLICABLE MOD ENABLED");
        } else {
            log.info("Collecting list of base hull specs from mod" + MOD_NAME + ".");
            ArrayList<String> modHullSpecs = getBaseHullSpecs(MOD_ID, SPOILER_RULE);
            // Grab tech types / manufacturers used by the mod
            ArrayList<String> modTechTypes = new ArrayList<>();
            for (Map.Entry<String, Integer> entry : modTechTypeByFrequency) {
                modTechTypes.add(entry.getKey());
            }
            log.info("Tech types from mod " + MOD_NAME + ": " + modTechTypes);
            // Grab common prefixes used by the mod for regular expression search
            String modPrefixRegex = getCommonPrefixRegex(MOD_ID, MIN_FOR_COMMON);
            ArrayList<String> factionsFromMod = getFactionsFromMod(MOD_ID);
            ArrayList<String> hullmodsFromMod = getHullmodsFromMod(MOD_ID);

            // Grab the hull variants to be placed in the mission
            log.info("-------------------------------------------");
            log.info("Collecting list of ships to add to mission.");
            log.info("-------------------------------------------");
            Set<FleetMemberAPI> baseHullsForMission = createFleetMembersFromBaseHulls(modHullSpecs, MODULES_LIST);
            ships.addAll(baseHullsForMission);
            Set<FleetMemberAPI> skinHullsForMission = createFleetMembersFromModSkins(
                    VANILLA_SHIP_ID_LIST,
                    modHullSpecs,
                    modTechTypes,
                    MODULES_LIST,
                    modPrefixRegex,
                    factionsFromMod,
                    hullmodsFromMod);
            ships.addAll(skinHullsForMission);

            //Add ships to mission
            boolean FIRST = true;
            for (FleetMemberAPI ship : ships) {
                String variant = ship.getVariant().getHullVariantId();
                api.addToFleet(FleetSide.PLAYER, variant, FleetMemberType.SHIP, FIRST);
                if (FIRST) {
                    FIRST = false;
                }
            }
            log.info("-------------------------------------------");
            log.info("Ships added to mission");
            log.info("-------------------------------------------");

            // Set a small blurb for each fleet that shows up on the mission detail and
            // mission results screens to identify each side.
            api.setFleetTagline(FleetSide.PLAYER, MOD_NAME + " Ships");

            String spoilerText = getSpoilerFilter(SPOILER_RULE);
            String weaponWingText = getWeaponWingFilter(WEAPON_WING_RULE, MOD_ID);
            String hullmodText = getHullmodFilter(HULLMOD_RULE);

            api.addBriefingItem("");
            api.addBriefingItem("");
            api.addBriefingItem("List of mods: " + getModsWithShips(true));
            api.addBriefingItem("Spoilers Filtered: " + spoilerText + " | Weapons/Wings Filtered: " + weaponWingText + " | Extra Hullmods: " + hullmodText);
        }
    }

}
