package data.missions.Hamatsu;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Personalities;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import java.util.List;
import org.apache.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class MissionDefinition implements MissionDefinitionPlugin {

    private static boolean deploy, END, FIRST = true;
    private static int clock, tech;
    private static float timer;

    public void defineMission(MissionDefinitionAPI api) {

        if (FIRST) {
            FIRST = false;
            tech = 2;
        }

        deploy = false;
        END = false;
        clock = 0;
        timer = 0;

        // Set up the fleets so we can add ships and fighter wings to them.
        // In this scenario, the fleets are attacking each other, but
        // in other scenarios, a fleet may be defending or trying to escape
        api.initFleet(FleetSide.PLAYER, "ISS", FleetGoal.ATTACK, false);
        api.initFleet(FleetSide.ENEMY, "ZIG", FleetGoal.ATTACK, true);

//		api.getDefaultCommander(FleetSide.PLAYER).getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 3);
//		api.getDefaultCommander(FleetSide.PLAYER).getStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 3);
        // Set a small blurb for each fleet that shows up on the mission detail and
        // mission results screens to identify each side.
        api.setFleetTagline(FleetSide.ENEMY, "One lonely Venture");

        // These show up as items in the bulleted list under 
        // "Tactical Objectives" on the mission detail screen
        api.addBriefingItem("Die die die.");

        if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
            tech = 0;
        } else if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
            tech = 1;
        } else if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
            tech = 2;
        }

        switch (tech) {
            case 0:
                api.setFleetTagline(FleetSide.PLAYER, "Low Tech Brawlers");
                api.addToFleet(FleetSide.PLAYER, "dominator_Outdated", FleetMemberType.SHIP, true);
                api.addToFleet(FleetSide.PLAYER, "venture_Balanced", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "mora_Assault", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "enforcer_Elite", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "buffalo2_Fighter_Support", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "lasher_Assault", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "gremlin_Strike", FleetMemberType.SHIP, false);
                break;
            case 1:
                api.setFleetTagline(FleetSide.PLAYER, "Midline Maulers");
                api.addToFleet(FleetSide.PLAYER, "hammerhead_Overdriven", FleetMemberType.SHIP, true);
                api.addToFleet(FleetSide.PLAYER, "gryphon_Standard", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "falcon_CS", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "centurion_Assault", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "brawler_Elite", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "monitor_Escort", FleetMemberType.SHIP, false);
                break;
            default: //case 2
                api.setFleetTagline(FleetSide.PLAYER, "High Tech Scholars");
                api.addToFleet(FleetSide.PLAYER, "hyperion_Strike", FleetMemberType.SHIP, true);
                api.addToFleet(FleetSide.PLAYER, "fury_Attack", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "tempest_Attack", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "omen_PD", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "afflictor_Strike", FleetMemberType.SHIP, false);
                api.addToFleet(FleetSide.PLAYER, "shade_Assault", FleetMemberType.SHIP, false);
        }

        // Set up the enemy fleet.
        FleetMemberAPI hamatsu = api.addToFleet(FleetSide.ENEMY, "scve_venture_Hamatsu", FleetMemberType.SHIP, "ZIG Hamatsu", true);
        PersonAPI person = hamatsu.getCaptain();
        person.setName(new FullName("Motes", "", Gender.ANY));
        person.setFaction(Factions.NEUTRAL);
        person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "ziggurat_captain"));
        person.setPersonality(Personalities.RECKLESS);
        person.setRankId(Ranks.SPACE_CAPTAIN);
        person.setPostId(null);

        person.getStats().setSkipRefresh(true);

        person.getStats().setLevel(12);
        person.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 2);
        person.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
        person.getStats().setSkillLevel(Skills.RELIABILITY_ENGINEERING, 2);
        person.getStats().setSkillLevel(Skills.RANGED_SPECIALIZATION, 2);
        person.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        //person.getStats().setSkillLevel(Skills.PHASE_MASTERY, 2);
        person.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);

        person.getStats().setSkillLevel(Skills.NAVIGATION, 1);

        /* from OMEGA core */
        person.getStats().setSkillLevel(Skills.SHIELD_MODULATION, 2);
        person.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 2);
        person.getStats().setSkillLevel(Skills.POINT_DEFENSE, 2);
        person.getStats().setSkillLevel(Skills.OMEGA_ECM, 2);

        person.getStats().setSkipRefresh(false);

        PersonAPI commander = api.getDefaultCommander(FleetSide.ENEMY);
        commander.getStats().setSkillLevel(Skills.WEAPON_DRILLS, 1);
        commander.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
        commander.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
        commander.getStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 1);
        commander.getStats().setSkillLevel(Skills.FLUX_REGULATION, 1);
        commander.getStats().setSkillLevel(Skills.DERELICT_CONTINGENT, 1);

        // Set up the map.
        float width = 10000f;
        float height = 10000f;
        api.initMap((float) -width / 2f, (float) width / 2f, (float) -height / 2f, (float) height / 2f);

        float minX = -width / 2;
        float minY = -height / 2;

        api.addPlugin(new Plugin());

    }

    public final static class Plugin implements EveryFrameCombatPlugin {

        public static Logger log = Global.getLogger(Plugin.class);

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            CombatEngineAPI engine = Global.getCombatEngine();

            if (!deploy) {
                deploy = true;

                /* makes the AI way worse
                 ShipAIConfig config = new ShipAIConfig();
                 config.alwaysStrafeOffensively = true;
                 config.backingOffWhileNotVentingAllowed = false;
                 config.turnToFaceWithUndamagedArmor = false;
                 config.burnDriveIgnoreEnemies = true;
                 config.personalityOverride = Personalities.RECKLESS;
                 */
                for (FleetMemberAPI member : engine.getFleetManager(FleetSide.ENEMY).getDeployedCopy()) {
                    ShipAPI ship = engine.getFleetManager(FleetSide.ENEMY).getShipFor(member);
                    ship.setCurrentCR(1);
                    //ship.setShipAI(Global.getSettings().createDefaultShipAI(ship, config));
                }
            }

            timer += engine.getElapsedInLastFrame();
            int playerAlive = 0, enemyAlive = 0;

            if (clock > 5 && timer > 1 && !END) {
                timer = 0;
                playerAlive = 0;
                enemyAlive = 0;

                //check for members alive
                for (FleetMemberAPI m : engine.getFleetManager(FleetSide.PLAYER).getDeployedCopy()) {
                    if (!m.isFighterWing()) {
                        playerAlive++;
                    }
                }

                for (FleetMemberAPI m : engine.getFleetManager(FleetSide.ENEMY).getDeployedCopy()) {
                    if (!m.isFighterWing()) {
                        enemyAlive++;
                    }
                }

                if (playerAlive == 0 || enemyAlive == 0) {
                    END = true;
                    log.info(playerAlive + ", " + enemyAlive);
                }
            }

            if (!END) {
                clock = (int) engine.getTotalElapsedTime(false);
                engine.maintainStatusForPlayerShip(
                        "clock",
                        null,
                        "Timer",
                        clock + " seconds",
                        true
                );
            } else {
                engine.maintainStatusForPlayerShip(
                        "clock",
                        null,
                        "Timer",
                        clock + " seconds",
                        false
                );
            }
        }

        //I don't know why I need these, they weren't in AI Battles.
        @Override
        public void processInputPreCoreControls(float amount, List<InputEventAPI> events) {
        }

        @Override
        public void renderInWorldCoords(ViewportAPI viewport) {
        }

        @Override
        public void renderInUICoords(ViewportAPI viewport) {
        }

        @Override
        public void init(CombatEngineAPI engine) {
        }

    }

}
