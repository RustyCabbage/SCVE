package data.missions.SecondWaveTester;

import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.Comparator_Utils.PRIORITY_SHIP;
import static data.scripts.Comparator_Utils.modTechTypeByFrequency;
import static data.scripts.Filter_Rules.getHullmodFilter;
import static data.scripts.Filter_Rules.getSpoilerFilter;
import static data.scripts.Filter_Rules.getWeaponWingFilter;
import static data.scripts.SCVE_Utils.HULLMOD_RULE;
import static data.scripts.SCVE_Utils.SPOILER_RULE;
import static data.scripts.SCVE_Utils.WEAPON_WING_RULE;
import static data.scripts.SCVE_Utils.initializeMissions;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;

public class MissionDefinition implements MissionDefinitionPlugin {

    public Logger log = Global.getLogger(MissionDefinition.class);

    public static String SECOND_WAVE_PREFIX = "secondwave";

    @Override
    public void defineMission(MissionDefinitionAPI api) {

        initializeMissions(api);

        modTechTypeByFrequency = null;
        Set<FleetMemberAPI> ships = new TreeSet<>(PRIORITY_SHIP);

        // Set a small blurb for each fleet that shows up on the mission detail and
        // mission results screens to identify each side.
        api.setFleetTagline(FleetSide.PLAYER, "Second Wave Ships");

        log.info("-------------------------------------------");
        log.info("Collecting list of ships to add to mission.");
        log.info("-------------------------------------------");

        //add base hulls
        for (String variantId : Global.getSettings().getAllVariantIds()) {
            if (variantId.startsWith("secondwave_")) {
                ShipVariantAPI variant = Global.getSettings().getVariant(variantId);
                FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, variant);
                ships.add(member);
                log.info("Variant " + variant.getHullVariantId() + " added to mission");
            }
        }

        //Add ships to mission
        boolean FIRST = true;
        for (FleetMemberAPI ship : ships) {
            String variant = ship.getVariant().getHullVariantId();
            api.addToFleet(FleetSide.PLAYER, variant, FleetMemberType.SHIP, FIRST);
            if (FIRST) {
                FIRST = false;
            }
        }
        log.info("-------------------------------------------");
        log.info("Ships added to mission");
        log.info("-------------------------------------------");

        String spoilerText = getSpoilerFilter(SPOILER_RULE);
        String weaponWingText = getWeaponWingFilter(WEAPON_WING_RULE, null);
        String hullmodText = getHullmodFilter(HULLMOD_RULE);

        api.addBriefingItem("Spoilers Hidden: " + spoilerText + " | Weapons/Wings Available: " + weaponWingText + " | Extra Hullmods: " + hullmodText);

    }

}
