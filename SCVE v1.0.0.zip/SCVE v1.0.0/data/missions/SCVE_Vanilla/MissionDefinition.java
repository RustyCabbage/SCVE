package data.missions.SCVE_Vanilla;

import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.Comparator_Utils.PRIORITY_SHIP;
import static data.scripts.Comparator_Utils.modTechTypeByFrequency;
import static data.scripts.Filter_Rules.getHullmodFilter;
import static data.scripts.Filter_Rules.getSpoilerFilter;
import static data.scripts.Filter_Rules.getWeaponWingFilter;
import static data.scripts.SCVE_Utils.HULLMOD_RULE;
import static data.scripts.SCVE_Utils.MODULES_LIST;
import static data.scripts.SCVE_Utils.SPOILER_RULE;
import static data.scripts.SCVE_Utils.VANILLA_SHIP_ID_LIST;
import static data.scripts.SCVE_Utils.WEAPON_WING_RULE;
import static data.scripts.SCVE_Utils.createFleetMembersFromBaseHulls;
import static data.scripts.SCVE_Utils.createFleetMembersFromVanillaSkins;
import static data.scripts.SCVE_Utils.initializeMissions;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;

public class MissionDefinition implements MissionDefinitionPlugin {

    public Logger log = Global.getLogger(MissionDefinition.class);

    @Override
    public void defineMission(MissionDefinitionAPI api) {

        initializeMissions(api);

        modTechTypeByFrequency = null;
        Set<FleetMemberAPI> ships = new TreeSet<>(PRIORITY_SHIP);

        // Set a small blurb for each fleet that shows up on the mission detail and
        // mission results screens to identify each side.
        api.setFleetTagline(FleetSide.PLAYER, "Vanilla Ships");

        log.info("-------------------------------------------");
        log.info("Collecting list of ships to add to mission.");
        log.info("-------------------------------------------");

        //add base hulls
        Set<FleetMemberAPI> baseHullsForMission = createFleetMembersFromBaseHulls(VANILLA_SHIP_ID_LIST, MODULES_LIST);
        ships.addAll(baseHullsForMission);

        Set<FleetMemberAPI> skinHullsForMission = createFleetMembersFromVanillaSkins(VANILLA_SHIP_ID_LIST, MODULES_LIST);
        ships.addAll(skinHullsForMission);

        //Add ships to mission
        boolean FIRST = true;
        for (FleetMemberAPI ship : ships) {
            String variant = ship.getVariant().getHullVariantId();
            api.addToFleet(FleetSide.PLAYER, variant, FleetMemberType.SHIP, FIRST);
            if (FIRST) {
                FIRST = false;
            }
        }
        log.info("-------------------------------------------");
        log.info("Ships added to mission");
        log.info("-------------------------------------------");

        String spoilerText = getSpoilerFilter(SPOILER_RULE);
        String weaponWingText = getWeaponWingFilter(WEAPON_WING_RULE, null);
        String hullmodText = getHullmodFilter(HULLMOD_RULE);

        api.addBriefingItem("Spoilers Filtered: " + spoilerText + " | Weapons/Wings Filtered: " + weaponWingText + " | Extra Hullmods: " + hullmodText);

    }

}
