package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import java.util.ArrayList;
import org.apache.log4j.Logger;

public class IntegrateHullmod extends BaseHullMod {

    public static Logger log = Global.getLogger(IntegrateHullmod.class);

    //private static final String HULLMOD_ID = "integratehullmod";
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        //ship.getVariant().removeMod(HULLMOD_ID);
        ArrayList<String> hullmods = (ArrayList<String>) ship.getVariant().getNonBuiltInHullmods();
        ship.getVariant().removeMod(hullmods.get(hullmods.size() - 1));
        hullmods.remove(hullmods.size() - 1);
        if (!hullmods.isEmpty()) {
            String lastHullmod = hullmods.get(hullmods.size() - 1);
            ship.getVariant().removeMod(lastHullmod);
            if (Global.getSettings().getHullModSpec(lastHullmod).hasTag("dmod")) {
                ship.getVariant().addPermaMod(lastHullmod, false);
                log.info("Integrated hullmod: " + lastHullmod + " as d-mod");
            } else {
                ship.getVariant().addPermaMod(lastHullmod, true);
                log.info("Integrated hullmod: " + lastHullmod + " as s-mod");
            }
        }
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (ship.getVariant().getNonBuiltInHullmods().isEmpty()) {
            return "Ship has no integrable hullmods.";
        }
        return null;
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().getNonBuiltInHullmods().isEmpty();
    }
}
