package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import java.util.ArrayList;
import java.util.Set;
import org.apache.log4j.Logger;

public class DisIntegrateHullmod extends BaseHullMod {

    public static Logger log = Global.getLogger(IntegrateHullmod.class);

    //private static final String HULLMOD_ID = "disintegratehullmod";
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        //ship.getVariant().removeMod(HULLMOD_ID);
        ArrayList<String> hullmods = (ArrayList<String>) ship.getVariant().getNonBuiltInHullmods();
        ship.getVariant().removeMod(hullmods.get(hullmods.size() - 1));
        hullmods.remove(hullmods.size() - 1);
        //LinkedHashSet<String> temp = ship.getVariant().getSMods();
        Set<String> temp = ship.getVariant().getPermaMods();
        ArrayList<String> permaMods = new ArrayList<>();
        permaMods.addAll(temp);
        if (!permaMods.isEmpty()) {
            String lastPermaMod = permaMods.get(permaMods.size() - 1);
            ship.getVariant().removePermaMod(lastPermaMod);
            ship.getVariant().addMod(lastPermaMod);
            log.info("Disintegrated hullmod: " + lastPermaMod);
        }
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        //if (ship.getVariant().getSMods().isEmpty()) {
        if (ship.getVariant().getPermaMods().isEmpty()) {
            if (!ship.getHullSpec().getBuiltInMods().isEmpty()) {
                for (String builtInMod : ship.getHullSpec().getBuiltInMods()) {
                    if (Global.getSettings().getHullModSpec(builtInMod).hasTag("dmod")) {
                        return "Cannot remove built-in d-mods.";
                    }
                }
            }
            return "Ship has no removable perma-mods.";
        }
        return null;
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return !ship.getVariant().getPermaMods().isEmpty();
        //return !ship.getVariant().getSMods().isEmpty();
    }
}
