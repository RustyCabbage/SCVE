package data.scripts;

import static data.scripts.Hullmod_Utils.MISSION_ONLY_HULLMODS;
import static data.scripts.SCVE_Utils.VANILLA_WEAPONS_LIST;
import static data.scripts.SCVE_Utils.VANILLA_WINGS_LIST;

public class Filter_Rules {

    public static String getSpoilerFilter(int spoilerRule) {
        String spoilerText = "";
        switch (spoilerRule) {
            case 0:
                spoilerText = "ALL";
                break;
            case 1:
                spoilerText = "MAJOR";
                break;
            case 2:
                spoilerText = "NONE";
                break;
        }
        return spoilerText;
    }

    public static String getWeaponWingFilter(int weaponWingRule, String modId) {
        /*
         Weapon/wing availability adjustments
         */
        String weaponWingText = "";
        SCVE_Utils.restoreAllWingsAndWeapons();
        switch (weaponWingRule) {
            case 0:
                Weapon_Utils.hideWeaponsFromOtherMods(modId, VANILLA_WEAPONS_LIST, true);
                Wing_Utils.hideWingsFromOtherMods(modId, VANILLA_WINGS_LIST, true);
                weaponWingText = "HEAVY";
                break;
            case 1:
                Weapon_Utils.hideWeaponsFromOtherMods(modId, VANILLA_WEAPONS_LIST, false);
                Wing_Utils.hideWingsFromOtherMods(modId, VANILLA_WINGS_LIST, false);
                weaponWingText = "LIGHT";
                break;
            case 2:
                weaponWingText = "DEFAULT";
                break;
            case 3:
                Weapon_Utils.showRestrictedWeapons();
                Wing_Utils.showRestrictedWings();
                weaponWingText = "NONE";
                break;
        }
        return weaponWingText;
    }

    public static String getHullmodFilter(int hullmodRule) {
        String hullmodText = "";
        switch (hullmodRule) {
            case 0:
                Hullmod_Utils.hideDMods();
                for (String hullmodId : MISSION_ONLY_HULLMODS) {
                    Hullmod_Utils.hideHullmod(hullmodId);
                }
                hullmodText = "NONE";
                break;
            case 1:
                Hullmod_Utils.hideDMods();
                for (String hullmodId : MISSION_ONLY_HULLMODS) {
                    Hullmod_Utils.unhideHullmod(hullmodId);
                }
                hullmodText = "S-MODS";
                break;
            case 2:
                Hullmod_Utils.unhideDMods();
                for (String hullmodId : MISSION_ONLY_HULLMODS) {
                    Hullmod_Utils.unhideHullmod(hullmodId);
                }
                hullmodText = "S/D-MODS";
                break;
        }
        return hullmodText;
    }

}
