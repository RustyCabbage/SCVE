package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Hullmod_Utils {

    public static Logger log = Global.getLogger(Hullmod_Utils.class);

    //public static final String VANILLA_HULLMOD_DATA = "data/config/SCVE/hull_mods_backup.csv";
    public static final String HULLMOD_DATA = "data/hullmods/hull_mods.csv";

    public static final ArrayList<String> MISSION_ONLY_HULLMODS = new ArrayList<>();
    /*
     static {
     MISSION_ONLY_HULLMODS.add("integratehullmod");
     MISSION_ONLY_HULLMODS.add("disintegratehullmod");
     } 
     */

    public static ArrayList<String> getHullmodsFromMod(String modId) {

        ArrayList<String> hullmodsFromMod = new ArrayList<>();
        //get mods which have a hullmods.csv
        ArrayList<String> sources = new ArrayList<>();
        try {
            JSONArray array = Global.getSettings().getMergedSpreadsheetDataForMod("id", HULLMOD_DATA, "starsector-core");
            int numRows = array.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = array.getJSONObject(i);
                String id = row.getString("id");
                if (!id.isEmpty()) {
                    String source = row.getString("fs_rowSource");
                    if (!sources.contains(source)) {
                        sources.add(source);
                        //log.info("Added source: " + source);
                    }
                }
            }
        } catch (IOException | JSONException ex) {
            log.info("Couldn't fetch " + HULLMOD_DATA);
        }
        //log.info("Hullmod sources: " + sources);

        //get mod name/id given path for all enabled non-utility mods
        ArrayList<String> modsWithHullmods = new ArrayList<>();
        List<ModSpecAPI> enabledMods = Global.getSettings().getModManager().getEnabledModsCopy();
        Map<String, String> pathMap = new HashMap<>();

        for (ModSpecAPI mod : enabledMods) {
            if (mod.isUtility()) {
                continue;
            }
            String path = mod.getPath();
            String id = mod.getId();

            pathMap.put(path, id);
        }
        //log.info("Path + Id: " + pathMap);

        //if a mod has a unique entry in hull_mods.csv, obtain its mod name/id and add it to the list
        for (String source : sources) {
            for (String path : pathMap.keySet()) {
                String modIdOrName = pathMap.get(path);
                if (source.contains(path) && !modsWithHullmods.contains(modIdOrName)) {
                    modsWithHullmods.add(modIdOrName);
                }
            }
        }
        log.info("Mods with hullmods: " + modsWithHullmods);

        //if the given modId isn't present (i.e. the mod doesn't add any hullmod), return
        //else find the hullmods
        if (!modsWithHullmods.contains(modId)) {
            return hullmodsFromMod;
        } else {
            try {
                JSONArray hullmods = Global.getSettings().loadCSV(HULLMOD_DATA, modId);
                int numRows = hullmods.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = hullmods.getJSONObject(i);
                    String hullmodId = row.getString("id");
                    if (!hullmodId.isEmpty()) {
                        hullmodsFromMod.add(hullmodId);
                    }
                }
            } catch (IOException | JSONException ex) {
                log.info("Couldn't fetch " + HULLMOD_DATA + " for " + modId);
            }
        }
        log.info("Hullmods from mod " + modId + ": " + hullmodsFromMod);
        return hullmodsFromMod;
    }

    public static void getMissionOnlyHullmods() {
        for (HullModSpecAPI hullmod : Global.getSettings().getAllHullModSpecs()) {
            String hullmodId = hullmod.getId();
            if (hullmod.getManufacturer().equals("Mission") && !MISSION_ONLY_HULLMODS.contains(hullmodId)) {
                MISSION_ONLY_HULLMODS.add(hullmodId);
            }
        }
    }

    public static void unhideDMods() {
        for (HullModSpecAPI hullmod : Global.getSettings().getAllHullModSpecs()) {
            if (hullmod.getTags().contains("dmod") && hullmod.isHidden()) {
                hullmod.addUITag("~DMod");
                hullmod.setHidden(false);
                //log.info("Added DMod UI tag and unhid dmod to " + hullmod.getDisplayName());
            }
        }
    }

    public static void hideDMods() {
        for (HullModSpecAPI hullmod : Global.getSettings().getAllHullModSpecs()) {
            if (hullmod.getTags().contains("dmod") && !hullmod.isHidden()) {
                hullmod.getUITags().remove("~DMod");
                hullmod.setHidden(true);
                //log.info("Removed DMod UI tag and hid dmod from " + hullmod.getDisplayName());
            }
        }
    }

    public static void hideHullmod(String hullmodId) {
        HullModSpecAPI hullmod = Global.getSettings().getHullModSpec(hullmodId);
        if (!hullmod.isHiddenEverywhere() || !hullmod.isHidden()) {
            hullmod.setHidden(true);
            hullmod.setHiddenEverywhere(true);
            log.info("Setting " + hullmodId + " to hidden and hiddenEverywhere");
        }
    }

    public static void unhideHullmod(String hullmodId) {
        HullModSpecAPI hullmod = Global.getSettings().getHullModSpec(hullmodId);
        if (hullmod.isHiddenEverywhere() || hullmod.isHidden()) {
            hullmod.setHidden(false);
            hullmod.setHiddenEverywhere(false);
            log.info("Removing hidden and hiddenEverywhere from " + hullmodId);
        }
    }

}
