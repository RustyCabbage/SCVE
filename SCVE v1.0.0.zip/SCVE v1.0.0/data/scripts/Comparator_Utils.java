package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import static data.scripts.SCVE_Utils.SHIP_DATA;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Comparator_Utils {

    public static Logger log = Global.getLogger(Comparator_Utils.class);

    public static final ArrayList<String> vanillaTechTypes = new ArrayList<>();
    public static Set<Map.Entry<String, Integer>> modTechTypeByFrequency = new HashSet<>();

    static {
        vanillaTechTypes.add("Low Tech");
        vanillaTechTypes.add("Midline");
        vanillaTechTypes.add("High Tech");
        vanillaTechTypes.add("Pirate");
        vanillaTechTypes.add("Luddic Path");
        vanillaTechTypes.add("Hegemony");
        vanillaTechTypes.add("XIV Battlegroup");
        vanillaTechTypes.add("Luddic Church");
        vanillaTechTypes.add("Tri-Tachyon");
        vanillaTechTypes.add("Explorarium");
        vanillaTechTypes.add("Remnant");
        vanillaTechTypes.add("Unknown");
    }
    public static final String LOW_TECH = vanillaTechTypes.get(0);
    public static final String MID_TECH = vanillaTechTypes.get(1);
    public static final String HIGH_TECH = vanillaTechTypes.get(2);

    /*
     Comparator for ordering the ships
     Adapted/stolen from DR's SWP Tester mission.
     */
    public static final Comparator<FleetMemberAPI> PRIORITY_SHIP = new Comparator<FleetMemberAPI>() {
        @Override
        public int compare(FleetMemberAPI member1, FleetMemberAPI member2) {
            boolean isGoalVariant1 = member1.getVariant().isGoalVariant();
            boolean isGoalVariant2 = member2.getVariant().isGoalVariant();
            boolean endsInD1 = endsWithD(member1);
            boolean endsInD2 = endsWithD(member2);
            boolean isSkin1 = isSkin(member1.getHullSpec());
            boolean isSkin2 = isSkin(member2.getHullSpec());
            int type1 = scoreTechTypesByFrequency(member1, modTechTypeByFrequency);
            int type2 = scoreTechTypesByFrequency(member2, modTechTypeByFrequency);
            String typeString1 = member1.getHullSpec().getManufacturer();
            String typeString2 = member2.getHullSpec().getManufacturer();
            int size1 = hullSizeToInt(member1);
            int size2 = hullSizeToInt(member2);
            float dp1 = member1.getStats().getSuppliesToRecover().getBaseValue();
            float dp2 = member2.getStats().getSuppliesToRecover().getBaseValue();
            String name1 = member1.getHullSpec().getHullName();
            String name2 = member2.getHullSpec().getHullName();
            String variantName1 = member1.getVariant().getDisplayName();
            String variantName2 = member2.getVariant().getDisplayName();
            // put goalVariants at the top. shouldn't matter for stripped hulls, but using this for other stuff
            if (isGoalVariant1 && !isGoalVariant2) {
                return -1;
            } else if (!isGoalVariant1 && isGoalVariant2) {
                return 1;
            }
            // put d-hulls at the bottom
            if (endsInD1 && !endsInD2) {
                return 1;
            } else if (!endsInD1 && endsInD2) {
                return -1;
            }
            // separate skins from standard (low / mid / high tech)
            if (type1 <= vanillaTechTypes.indexOf(HIGH_TECH) || type2 <= vanillaTechTypes.indexOf(HIGH_TECH)) {
                if (isSkin1 && !isSkin2) {
                    return 1;
                } else if (!isSkin1 && isSkin2) {
                    return -1;
                }
            }
            /*
             if different tech type, sort by standard order
             if different tech type and non-standard, sort alphabetically by tech type
             if same tech type, sort by hull size
             if same hull size, sort by DP
             if same DP sort by hull name
             if same hull name sort by variant name
             if same variant name sort by id
             */
            if (Float.compare(type1, type2) == 0) {
                if (!typeString1.equals(typeString2)) {
                    return typeString1.compareTo(typeString2);
                }
                if (Float.compare(size1, size2) == 0) {
                    if (Float.compare(dp1, dp2) == 0) {
                        if (name1.compareTo(name2) != 0) {
                            return name1.compareTo(name2);
                        } else {
                            if (variantName1.compareTo(variantName2) != 0) {
                                return variantName1.compareTo(variantName2);
                            } else {
                                return member1.getId().compareTo(member2.getId());
                            }
                        }
                    } else {
                        return Float.compare(dp1, dp2);
                    }
                } else {
                    return Float.compare(size1, size2);
                }
            } else {
                return Float.compare(type1, type2);
            }
        }
    };

    /*
     Comparator for sorting maps
     */
    public static final Comparator<Map.Entry<String, Integer>> PRIORITY_MAP = new Comparator<Map.Entry<String, Integer>>() {
        @Override
        public int compare(Map.Entry<String, Integer> map1, Map.Entry<String, Integer> map2) {
            if (Float.compare(map2.getValue(), map1.getValue()) == 0) {
                return map2.getKey().compareTo(map1.getKey());
            } else {
                return Float.compare(map2.getValue(), map1.getValue());
            }
        }
    };

    /*
     Miscellaneous methods
     */
    public static boolean endsWithD(FleetMemberAPI member) {
        return member.getHullSpec().getHullId().endsWith("_d");
    }

    public static boolean isSkin(ShipHullSpecAPI hullSpec) {
        return hullSpec.getShipFilePath().endsWith(".skin");
    }

    /*
     Tech types from Vanilla
     Used for sorting in the comparator
     */
    public static int techTypeToInt(FleetMemberAPI member) {
        String techType = member.getHullSpec().getManufacturer();
        if (vanillaTechTypes.contains(techType)) {
            for (String vanillaTechType : vanillaTechTypes) {
                if (techType.equals(vanillaTechType)) {
                    return vanillaTechTypes.indexOf(vanillaTechType);
                }
            }
        }
        //non-vanilla tech types go last using this method
        return 999;
    }

    /*
     Used for sorting in the comparator
     */
    public static int hullSizeToInt(FleetMemberAPI member) {
        if (member.isFrigate()) {
            return 1;
        } else if (member.isDestroyer()) {
            return 2;
        } else if (member.isCruiser()) {
            return 3;
        } else if (member.isCapital()) {
            return 4;
        } else {
            return -1;
        }
    }

    /*
     Sorts the tech types based on their frequency in the mod
     If the standard low/mid/high tech appear more often than the most used non-standard tech (as in ship packs)
     it will start with them regardless of which is most frequent
     Used for sorting in the comparator
     */
    public static int scoreTechTypesByFrequency(FleetMemberAPI member, Set<Map.Entry<String, Integer>> techTypeByFrequency) {
        // in case you just want to use vanilla settings
        if (techTypeByFrequency == null) {
            return techTypeToInt(member);
        }
        // in case something breaks
        if (techTypeByFrequency.isEmpty()) {
            return 999;
        }
        // check the total number of low/mid/high tech hulls and see if any single other tech type has more than them combined
        // goal is to have ship packs still sort by low/mid/high hulls, but faction mods sort their factions first
        int totalStandard = 0;
        int maxNonStandard = 0;
        for (Map.Entry<String, Integer> entry : techTypeByFrequency) {
            //if (entry.getKey().equals(LOW_TECH) || entry.getKey().equals(MID_TECH) || entry.getKey().equals(HIGH_TECH)) {
            if (vanillaTechTypes.contains(entry.getKey())) {
                totalStandard += entry.getValue();
            } else if (entry.getValue() > maxNonStandard) {
                maxNonStandard = entry.getValue();
            }
        }

        //if the total number of standard hulls exceeds that of a single type, do a default sort
        String memberTechType = member.getHullSpec().getManufacturer();
        if (totalStandard > maxNonStandard) {
            /*
             if (memberTechType.equals(LOW_TECH)) {
             return -9999;
             } else if (memberTechType.equals(MID_TECH)) {
             return -9998;
             } else if (memberTechType.equals(HIGH_TECH)) {
             return -9997;
             }
             */
            return techTypeToInt(member);
        }
        //else sort in order of frequency as per usual
        for (Map.Entry<String, Integer> entry : techTypeByFrequency) {
            if (entry.getKey().equals(memberTechType)) {
                return entry.getValue() * -1;
            }
        }
        // if the tech type is somehow not in the set, put it at the bottom
        return 999;
    }

    /*
     Gets the frequency of every tech type used in the mod's ship_data.csv
     TODO: Should maybe consider skins too? But they're listed separately anyways...
     */
    public static Set<Map.Entry<String, Integer>> getTechTypesByFrequency(String modId) {
        Set<Map.Entry<String, Integer>> sortedTechTypeFrequency = new TreeSet<>(PRIORITY_MAP);
        // I need this stupid catch here but not in any of the other methods ugh
        if (!Global.getSettings().getModManager().isModEnabled(modId)) {
            return sortedTechTypeFrequency;
        }
        Map<String, Integer> unsortedTechTypeFrequency = new HashMap<>();
        try {
            JSONArray ship_data = Global.getSettings().loadCSV(SHIP_DATA, modId);
            int numRows = ship_data.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = ship_data.getJSONObject(i);
                String id = row.getString("id");
                String tech = row.getString("tech/manufacturer");
                if (!id.isEmpty() && !tech.isEmpty()) {
                    String emptyHullVariantId = id + "_Hull";
                    ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
                    if (variant != null && !variant.isFighter() && !variant.isStation()) {
                        if (unsortedTechTypeFrequency.keySet().contains(tech)) {
                            Integer timesUsed = unsortedTechTypeFrequency.get(tech) + 1;
                            unsortedTechTypeFrequency.put(tech, timesUsed);
                        } else {
                            unsortedTechTypeFrequency.put(tech, 1);
                        }
                    }
                }
            }
            sortedTechTypeFrequency.addAll(unsortedTechTypeFrequency.entrySet());
            log.info("Tech Types sorted by usage: " + sortedTechTypeFrequency);
        } catch (IOException | JSONException ex) {
            log.info("Error fetching vanilla base hulls");
        }
        return sortedTechTypeFrequency;
    }

}
