package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import static data.scripts.Hullmod_Utils.MISSION_ONLY_HULLMODS;
import static data.scripts.SCVE_Utils.HULLMOD_RULE;
import static data.scripts.SCVE_Utils.ORIGINAL_WEAPON_TAGS_MAP;
import static data.scripts.SCVE_Utils.ORIGINAL_WING_OP_COST_MAP;
import static data.scripts.SCVE_Utils.ORIGINAL_WING_TAGS_MAP;
import static data.scripts.SCVE_Utils.WEAPON_WING_RULE;
import org.apache.log4j.Logger;

public class SCVE_Plugin extends BaseModPlugin {

    public static Logger log = Global.getLogger(SCVE_Plugin.class);

    @Override
    public void onGameLoad(boolean newGame) {
        /*
         prevents something weird happening in campaign if the user forgets to restore to default before playing
         */
        if (WEAPON_WING_RULE != 2) {
            Weapon_Utils.restoreWeaponTags(ORIGINAL_WEAPON_TAGS_MAP);
            Wing_Utils.restoreWingTags(ORIGINAL_WING_TAGS_MAP);
            Wing_Utils.restoreWingOPCosts(ORIGINAL_WING_OP_COST_MAP);
            WEAPON_WING_RULE = 2;
            log.info("Hey you forgot to restore the weapons/wings before going back to the campaign, dummy.");
        }

        /*
         these hullmods should not appear in campaign
         */
        log.info("Campaign loaded - cleaning hullmods");
        HULLMOD_RULE = 0;
        Hullmod_Utils.hideDMods();
        Hullmod_Utils.getMissionOnlyHullmods();
        for (String hullmodId : MISSION_ONLY_HULLMODS) {
            Hullmod_Utils.hideHullmod(hullmodId);
        }

    }

    // I don't think this is necessary?
    /*
     @Override
     public void onDevModeF8Reload() {
     ORIGINAL_WEAPON_TAGS_MAP = getWeaponTagsMap();
     ORIGINAL_WING_TAGS_MAP = getWingTagsMap();
     ORIGINAL_WING_OP_COST_MAP = getWingOPCostMap();
     }
     */

    /*
     @Override
     public void onApplicationLoad() throws Exception {
     ORIGINAL_WING_TAGS_MAP = getWingTagsMap();
     for (FighterWingSpecAPI w : Global.getSettings().getAllFighterWingSpecs()) {
     if (!w.getTags().toString().matches(".*(fighter|bomber|interceptor)[0-9].*")) {
     w.getTags().add("fighter0");
     w.getTags().add("restricted");
     log.info("Adding tags fighter0 & restricted to " + w.getWingName());
     }
     }
     }
     */
}
