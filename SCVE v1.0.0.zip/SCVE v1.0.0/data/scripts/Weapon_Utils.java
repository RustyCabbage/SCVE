package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Weapon_Utils {

    public static Logger log = Global.getLogger(Weapon_Utils.class);

    public static final String VANILLA_WEAPON_DATA = "data/config/SCVE/weapon_data_backup.csv";
    public static final String WEAPON_DATA = "data/weapons/weapon_data.csv";
    public static String RESTRICTED = "restricted";

    public static HashMap<String, Set<String>> getWeaponTagsMap() {
        HashMap<String, Set<String>> weaponTagsMap = new HashMap<>();
        for (WeaponSpecAPI w : Global.getSettings().getAllWeaponSpecs()) {
            Set<String> tags = new HashSet<>();
            tags.addAll(w.getTags());
            weaponTagsMap.put(w.getWeaponId(), tags);
        }
        return weaponTagsMap;
    }

    public static void restoreWeaponTags(HashMap<String, Set<String>> weaponTagsMap) {
        log.info("Restoring weapon tags...");
        for (String id : weaponTagsMap.keySet()) {
            WeaponSpecAPI weapon = Global.getSettings().getWeaponSpec(id);
            weapon.getTags().clear();
            weapon.getTags().addAll(weaponTagsMap.get(id));
        }
        log.info("Done restoring weapon tags.");
    }

    public static void showRestrictedWeapons() {
        log.info("Removing restricted tag from weapons...");
        for (WeaponSpecAPI w : Global.getSettings().getAllWeaponSpecs()) {
            if (w.hasTag(RESTRICTED)) {
                w.getTags().remove(RESTRICTED);
                log.info("Removed restricted tag from weapon " + w.getWeaponName());
            }
        }
        log.info("Finished removing restricted tag from weapons.");
    }

    public static ArrayList<String> getVanillaWeapons() {
        ArrayList<String> vanillaWeapons = new ArrayList<>();
        try {
            JSONArray weapon_data = Global.getSettings().loadCSV(VANILLA_WEAPON_DATA);
            int numRows = weapon_data.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = weapon_data.getJSONObject(i);
                String id = row.getString("id");
                String hints = row.getString("hints");
                //filters out systems and decos
                if (!id.isEmpty()
                        && !hints.contains("SYSTEM")) {
                    vanillaWeapons.add(id);
                }
            }
            log.info("List of vanilla weapons loaded.");
        } catch (IOException | JSONException ex) {
            log.info("Error fetching vanilla weapons.");
        }

        return vanillaWeapons;
    }

    //add exceptions for SWP?
    public static void hideWeaponsFromOtherMods(String modId, ArrayList<String> vanillaWeapons, boolean hideVanilla) {
        log.info("Hiding weapons from mods that aren't from " + modId + "...");
        if (hideVanilla) {
            log.info("Also hiding vanilla weapons.");
        }
        ArrayList<String> weaponsFromMod = new ArrayList<>();
        if (!(modId == null)) {
            weaponsFromMod = getWeaponsFromMod(modId);
        }
        for (WeaponSpecAPI weapon : Global.getSettings().getAllWeaponSpecs()) {
            String id = weapon.getWeaponId();
            if (!weaponsFromMod.contains(id) && !weapon.hasTag(RESTRICTED)) {
                if (!hideVanilla) {
                    if (!vanillaWeapons.contains(id)) {
                        weapon.addTag(RESTRICTED);
                    }
                } else {
                    weapon.addTag(RESTRICTED);
                }
            }
        }
        log.info("Done hiding weapons from other mods.");
    }

    public static ArrayList<String> getWeaponsFromMod(String modId) {

        ArrayList<String> weaponsFromMod = new ArrayList<>();
        //get mods which have a weapons.csv
        ArrayList<String> sources = new ArrayList<>();
        try {
            JSONArray array = Global.getSettings().getMergedSpreadsheetDataForMod("id", WEAPON_DATA, "starsector-core");
            int numRows = array.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = array.getJSONObject(i);
                String id = row.getString("id");
                if (!id.isEmpty()) {
                    String source = row.getString("fs_rowSource");
                    if (!sources.contains(source)) {
                        sources.add(source);
                        //log.info("Added source: " + source);
                    }
                }
            }
        } catch (IOException | JSONException ex) {
            log.info("Couldn't fetch weapon_data.csv.");
        }
        //log.info("Weapon sources: " + sources);

        //get mod name/id given path for all enabled non-utility mods
        ArrayList<String> modsWithWeapons = new ArrayList<>();
        List<ModSpecAPI> enabledMods = Global.getSettings().getModManager().getEnabledModsCopy();
        Map<String, String> pathMap = new HashMap<>();

        for (ModSpecAPI mod : enabledMods) {
            if (mod.isUtility()) {
                continue;
            }
            String path = mod.getPath();
            String id = mod.getId();

            pathMap.put(path, id);
        }
        //log.info("Path + Id: " + pathMap);

        //if a mod has a unique entry in weapon_data.csv, obtain its mod name/id and add it to the list
        for (String source : sources) {
            for (String path : pathMap.keySet()) {
                String modIdOrName = pathMap.get(path);
                if (source.contains(path) && !modsWithWeapons.contains(modIdOrName)) {
                    modsWithWeapons.add(modIdOrName);
                }
            }
        }
        log.info("Mods with weapons: " + modsWithWeapons);

        //if the given modId isn't present (i.e. the mod doesn't add any weapon), return
        //else find the weapons
        if (!modsWithWeapons.contains(modId)) {
            return weaponsFromMod;
        } else {
            try {
                JSONArray weapons = Global.getSettings().loadCSV(WEAPON_DATA, modId);
                int numRows = weapons.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = weapons.getJSONObject(i);
                    String weaponId = row.getString("id");
                    if (!weaponId.isEmpty()) {
                        weaponsFromMod.add(weaponId);
                    }
                }
            } catch (IOException | JSONException ex) {
                log.info("Couldn't fetch weapon_data.csv for " + modId + ".");
            }
        }
        log.info("Weapons from mod " + modId + ": " + weaponsFromMod);
        return weaponsFromMod;
    }
}
