package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import static data.scripts.Comparator_Utils.PRIORITY_MAP;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.lwjgl.input.Keyboard;

/*
 TODO:
 Instead of loading from a backup I have to copy paste, use getMergedSpreadSheetData and look for null/<speadsheet_name>
 */
public class SCVE_Utils {

    /*
     A bunch of variables used in the mod.
     */
    public static Logger log = Global.getLogger(SCVE_Utils.class);
    public static final String VANILLA_SHIP_DATA = "data/config/SCVE/ship_data_backup.csv";
    public static final String SHIP_DATA = "data/hulls/ship_data.csv";
    public static final String FACTION_DATA = "data/world/factions/factions.csv";

    public static boolean GLOBAL_FIRST_LOAD = true;
    public static ArrayList<String> VANILLA_SHIP_ID_LIST;
    public static Set<String> MODULES_LIST;
    public static ArrayList<String> MODS_WITH_SHIPS_LIST;
    public static ArrayList<String> MODS_WITH_SHIPS_NAMES_LIST;

    public static int SPOILER_RULE = 1, WEAPON_WING_RULE = 2, HULLMOD_RULE = 0;
    public static String BLOCK_ALL_SPOILERS = "HIDE_IN_CODEX"; //hint
    public static String BLOCK_HEAVY_SPOILERS = "restricted"; //tag

    public static HashMap<String, Set<String>> ORIGINAL_WEAPON_TAGS_MAP;
    public static HashMap<String, Set<String>> ORIGINAL_WING_TAGS_MAP;
    public static HashMap<String, Float> ORIGINAL_WING_OP_COST_MAP;
    public static ArrayList<String> VANILLA_WEAPONS_LIST;
    public static ArrayList<String> VANILLA_WINGS_LIST;

    /*
     if returnNames is true, it returns a list of mod names, else it returns a list of mod IDs
     */
    public static void initializeMissions(MissionDefinitionAPI api) {
        if (GLOBAL_FIRST_LOAD) {
            GLOBAL_FIRST_LOAD = false;

            MODULES_LIST = getModules();
            MODS_WITH_SHIPS_LIST = getModsWithShips(false);
            MODS_WITH_SHIPS_NAMES_LIST = getModsWithShips(true);

            ORIGINAL_WEAPON_TAGS_MAP = Weapon_Utils.getWeaponTagsMap();
            ORIGINAL_WING_TAGS_MAP = Wing_Utils.getWingTagsMap();
            ORIGINAL_WING_OP_COST_MAP = Wing_Utils.getWingOPCostMap();
            VANILLA_WEAPONS_LIST = Weapon_Utils.getVanillaWeapons();
            VANILLA_WINGS_LIST = Wing_Utils.getVanillaWings();

            Hullmod_Utils.getMissionOnlyHullmods();
        }

        /*
         SPACE - default everything
        
         Q - spoiler filter left
         W - spoiler filter right
         0 = block all spoilers
         1 = block heavy spoilers
         2 = block no spoilers
        
         A - weapon filter left
         S - weapon filter right
         0 = block all weapons not from the mod
         1 = block all mod weapons not from the mod
         2 = default (block restricted weapons)
         3 = allow all weapons
        
         Z - hullmod filter left
         X - hullmod filter right
         0 - default
         1 - show s-mod integration hullmod
         2 - show d-mods
         */
        if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
            SPOILER_RULE = 1;
            WEAPON_WING_RULE = 2;
            HULLMOD_RULE = 0;
        } else if (Keyboard.isKeyDown(Keyboard.KEY_Q)) {
            SPOILER_RULE--;
            if (SPOILER_RULE < 0) {
                SPOILER_RULE = 2;
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
            SPOILER_RULE++;
            if (SPOILER_RULE > 2) {
                SPOILER_RULE = 0;
            }
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
            WEAPON_WING_RULE--;
            if (WEAPON_WING_RULE < 0) {
                WEAPON_WING_RULE = 3;
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
            WEAPON_WING_RULE++;
            if (WEAPON_WING_RULE > 3) {
                WEAPON_WING_RULE = 0;
            }
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_Z)) {
            HULLMOD_RULE--;
            if (HULLMOD_RULE < 0) {
                HULLMOD_RULE = 2;
            }
        } else if (Keyboard.isKeyDown(Keyboard.KEY_X)) {
            HULLMOD_RULE++;
            if (HULLMOD_RULE > 2) {
                HULLMOD_RULE = 0;
            }
        }

        VANILLA_SHIP_ID_LIST = getBaseHullSpecs(null, SPOILER_RULE);

        // Set up the fleets so we can add ships and fighter wings to them.
        // In this scenario, the fleets are attacking each other, but
        // in other scenarios, a fleet may be defending or trying to escape
        api.initFleet(FleetSide.PLAYER, "ABC", FleetGoal.ATTACK, false);
        api.initFleet(FleetSide.ENEMY, "TAR", FleetGoal.ATTACK, true);

        // Set up the map.
        float width = 10000f;
        float height = 10000f;
        api.initMap((float) -width / 2f, (float) width / 2f, (float) -height / 2f, (float) height / 2f);

        // Set up the enemy fleet.
        api.setFleetTagline(FleetSide.ENEMY, "Target Practice");
        api.addToFleet(FleetSide.ENEMY, "atlas_Standard", FleetMemberType.SHIP, false);
    }

    public static void restoreAllWingsAndWeapons() {
        Weapon_Utils.restoreWeaponTags(ORIGINAL_WEAPON_TAGS_MAP);
        Wing_Utils.restoreWingTags(ORIGINAL_WING_TAGS_MAP);
        Wing_Utils.restoreWingOPCosts(ORIGINAL_WING_OP_COST_MAP);
    }

    public static ArrayList<String> getModsWithShips(boolean returnNames) {
        ArrayList<String> sources = new ArrayList<>();
        //get mods which have a ship_data.csv
        try {
            JSONArray array = Global.getSettings().getMergedSpreadsheetDataForMod("id", SHIP_DATA, "starsector-core");
            int numRows = array.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = array.getJSONObject(i);
                String id = row.getString("id");
                if (!id.isEmpty()) {
                    String source = row.getString("fs_rowSource");
                    if (!sources.contains(source)) {
                        sources.add(source);
                        log.info("Added source: " + source);
                    }
                }
            }
        } catch (IOException | JSONException ex) {
            log.info("Couldn't fetch ship_data.csv.");
        }

        //get mod name/id given path for all enabled non-utility mods
        ArrayList<String> modsWithShips = new ArrayList<>();
        List<ModSpecAPI> enabledMods = Global.getSettings().getModManager().getEnabledModsCopy();
        Map<String, String> pathMap = new HashMap<>();

        for (ModSpecAPI mod : enabledMods) {
            if (mod.isUtility()) {
                continue;
            }
            String path = mod.getPath();
            String id = mod.getId();
            String name = mod.getName();

            if (returnNames) {
                pathMap.put(path, name);
            } else {
                pathMap.put(path, id);
            }
        }

        //if a mod has a unique entry in ship_data.csv, obtain its mod name/id and add it to the list
        for (String source : sources) {
            for (String path : pathMap.keySet()) {
                String modIdOrName = pathMap.get(path);
                if (source.contains(path) && !modsWithShips.contains(modIdOrName)) {
                    modsWithShips.add(modIdOrName);
                }
            }
        }
        return modsWithShips;
    }

    /*
     Obtains a list of the Hull variant faction of all modules
     Used for creating blacklists
     */
    public static Set<String> getModules() {
        Set<String> modules = new HashSet<>();
        for (ShipHullSpecAPI hullSpec : Global.getSettings().getAllShipHullSpecs()) {
            if (hullSpec.isDefaultDHull()) {
                continue;
            }
            String id = hullSpec.getHullId();
            String emptyHullVariantId = id + "_Hull";
            ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
            Set<String> tags = hullSpec.getTags();
            List<String> moduleTags = Arrays.asList("module_no_status_bar", "module_hull_bar_only");

            if (variant == null) {
                log.info("No variant found for " + emptyHullVariantId);
                continue;
            }
            if (!variant.getStationModules().isEmpty()) {
                modules.addAll(variant.getStationModules().values());
            } else if (!Collections.disjoint(tags, moduleTags) || emptyHullVariantId.contains("module_")) {
                modules.add(emptyHullVariantId);
            }
        }
        log.info("List of modules loaded.");
        return modules;
    }

    /*
     Grabs a list of base hull specs
     Two cases: one for vanilla (modId == null) and one for mods
     */
    public static ArrayList<String> getBaseHullSpecs(String modId, int spoilerRule) {
        ArrayList<String> baseHullSpecs = new ArrayList<>();
        if (modId == null) {
            try {
                JSONArray ship_data = Global.getSettings().loadCSV(VANILLA_SHIP_DATA);
                int numRows = ship_data.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = ship_data.getJSONObject(i);
                    String id = row.getString("id");
                    String tech = row.getString("tech/manufacturer");
                    //filters out drones, fighters, modules
                    if (!id.isEmpty()
                            && !tech.isEmpty()) {
                        //check spoiler rule
                        //log.info("Checking if " + id + " is a spoiler.");
                        boolean BLOCKED_BY_SPOILER_RULE = false;
                        String hints = row.getString("hints");
                        String tags = row.getString("tags");
                        switch (spoilerRule) {
                            case 0:
                                //log.info("CASE 0: BLOCK ALL SPOILERS");
                                if (hints.contains(BLOCK_ALL_SPOILERS)) {
                                    BLOCKED_BY_SPOILER_RULE = true;
                                }
                                break;
                            case 1:
                                //log.info("CASE 1: BLOCK HEAVY SPOILERS");
                                //Ziggy is a heavy spoiler for now
                                if (tags.contains(BLOCK_HEAVY_SPOILERS) || id.equals("ziggurat")) {
                                    BLOCKED_BY_SPOILER_RULE = true;
                                }
                                break;
                            case 2:
                                //log.info("CASE 2: BLOCK NO SPOILERS");
                                break; // do nothing
                        }
                        if (!BLOCKED_BY_SPOILER_RULE) {
                            baseHullSpecs.add(id);
                        } else {
                            log.info("Hull spec " + id + " is blocked by spoiler rule " + spoilerRule + ".");
                        }
                    }
                }
                log.info("List of vanilla base hulls loaded.");
            } catch (IOException | JSONException ex) {
                log.info("Error fetching vanilla base hulls");
            }
        } else {
            try {
                JSONArray ship_data = Global.getSettings().loadCSV(SHIP_DATA, modId);
                int numRows = ship_data.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = ship_data.getJSONObject(i);
                    String name = row.getString("name");
                    String id = row.getString("id");
                    String tech = row.getString("tech/manufacturer");
                    //String tags = row.getString("tags");
                    String DP = row.getString("supplies/rec");
                    String OP = row.getString("ordnance points");
                    //filters out drones, fighters, modules
                    //must have (name or techtype) and faction
                    if ((!name.isEmpty() || !tech.isEmpty())
                            && !id.isEmpty()
                            && !DP.equals("0")
                            && !OP.equals("0")) {
                        //check spoiler rule
                        //log.info("Checking if " + id + " is a spoiler.");
                        boolean BLOCKED_BY_SPOILER_RULE = false;
                        String hints = row.getString("hints");
                        String tags = row.getString("tags");
                        switch (spoilerRule) {
                            case 0:
                                //log.info("CASE 0: BLOCK ALL SPOILERS");
                                if (hints.contains(BLOCK_ALL_SPOILERS)) {
                                    BLOCKED_BY_SPOILER_RULE = true;
                                }
                                break;
                            case 1:
                                //log.info("CASE 1: BLOCK HEAVY SPOILERS");
                                if (tags.contains(BLOCK_HEAVY_SPOILERS)) {
                                    BLOCKED_BY_SPOILER_RULE = true;
                                }
                                break;
                            case 2:
                                //log.info("CASE 2: BLOCK NO SPOILERS");
                                break; // do nothing
                        }
                        if (!BLOCKED_BY_SPOILER_RULE) {
                            baseHullSpecs.add(id);
                        } else {
                            log.info("Hull spec " + id + "is blocked by spoiler rule " + spoilerRule + ".");
                        }
                    }
                }
                log.info("List of mod base hulls loaded.");
            } catch (IOException | JSONException ex) {
                log.info("Error fetching mod base hulls");

            }
        }
        return baseHullSpecs;
    }

    /*
     Grab all base hulls given a list of hullSpecs and a blacklist
     */
    public static Set<FleetMemberAPI> createFleetMembersFromBaseHulls(ArrayList<String> hullSpecs, Set<String> blacklistedVariants) {
        Set<FleetMemberAPI> ships = new HashSet<>();
        for (String id : hullSpecs) {
            String emptyHullVariantId = id + "_Hull";
            ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
            if (variant.isFighter() || variant.isStation() || blacklistedVariants.contains(emptyHullVariantId)) {
                continue;
            }
            FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, emptyHullVariantId);
            ships.add(member);
            log.info("Base hull " + id + " added to mission.");
        }
        return ships;
    }

    /*
     Grab skins of vanilla base hulls given a list of base hullSpecs and a blacklist
     */
    public static Set<FleetMemberAPI> createFleetMembersFromVanillaSkins(ArrayList<String> hullSpecs, Set<String> blacklistedVariants) {
        Set<FleetMemberAPI> ships = new HashSet<>();
        for (ShipHullSpecAPI hullSpec : Global.getSettings().getAllShipHullSpecs()) {
            String id = hullSpec.getHullId();
            //only want skins from vanilla
            if (!hullSpecs.contains(hullSpec.getBaseHullId())
                    || hullSpec.isDefaultDHull()
                    || !Comparator_Utils.isSkin(hullSpec)
                    || !hullSpec.getShipFilePath().contains("starsector-core")) {
                continue;
            }
            String emptyHullVariantId = id + "_Hull";
            ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
            if (variant.isFighter() || variant.isStation() || blacklistedVariants.contains(emptyHullVariantId)) {
                continue;
            }
            FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, emptyHullVariantId);
            ships.add(member);
            log.info("Skin " + id + " added to mission.");
        }
        return ships;
    }

    /*
     Grab skins added by a given mod
     */
    public static Set<FleetMemberAPI> createFleetMembersFromModSkins(
            ArrayList<String> vanillaHullSpecs,
            ArrayList<String> modHullSpecs,
            ArrayList<String> modTechTypes,
            Set<String> blacklistedVariants,
            String prefixRegex,
            ArrayList<String> factionsFromMod,
            ArrayList<String> hullmodsFromMod) {
        Set<FleetMemberAPI> ships = new HashSet<>();
        boolean invalidModSkin;
        for (ShipHullSpecAPI hullSpec : Global.getSettings().getAllShipHullSpecs()) {
            invalidModSkin = hullSpec.isDefaultDHull() || !Comparator_Utils.isSkin(hullSpec) || hullSpec.getShipFilePath().contains("starsector-core");
            if (invalidModSkin) {
                continue;
            }
            String id = hullSpec.getHullId();
            String baseId = hullSpec.getBaseHullId();
            String techType = hullSpec.getManufacturer();
            //only want skins from the given mod
            //if it is a mod hullspec or if its manufacturer is a faction from the mod then do the stuff
            //other possibilities: check built-in wings for a modded one
            //nuclear option: variant list map and look for variants with mod weapons :skull:
            if (modHullSpecs.contains(baseId)
                    || (vanillaHullSpecs.contains(baseId) && (factionsFromMod.contains(techType) || !Collections.disjoint(hullmodsFromMod, hullSpec.getBuiltInMods()))) //vanilla hull with tech type as faction from mod
                    ) {
                //do the stuff
                String emptyHullVariantId = id + "_Hull";
                ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
                if (variant.isFighter() || variant.isStation() || blacklistedVariants.contains(emptyHullVariantId)) {
                    continue;
                }
                FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, emptyHullVariantId);
                ships.add(member);
                log.info("Skin " + id + " added to mission - mod ship skin or base skin with mod tech/hullmod");

                //add the tech type to the list if it isn't already present in the list
                if (!modTechTypes.contains(techType)) {
                    modTechTypes.add(techType);
                    //log.info("Adding new tech type " + techType + " from hull spec " + id);
                }

                //THIS WAS NECESSARY 'CUZ OF VSP'S BUFFALO 2 (LC), THANKS A LOT.
                //second condition: vanilla hull with tech type from given mod and proper mod prefix
            } else if (vanillaHullSpecs.contains(baseId) && modTechTypes.contains(techType) && hullSpec.getShipFilePath().matches(prefixRegex)) {
                //log.info(modTechTypes);

                //do the stuff
                String emptyHullVariantId = id + "_Hull";
                ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
                if (variant.isFighter() || variant.isStation() || blacklistedVariants.contains(emptyHullVariantId)) {
                    continue;
                }
                FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, emptyHullVariantId);
                ships.add(member);
                log.info("Skin " + id + " added to mission - base skin with mod tech and prefix");
            }

            /*
             //THIS WAS NECESSARY 'CUZ OF VSP'S XIV BATTLEGROUP SHIPS, I HATE EVERYTHING
             //third condition: vanilla hull with tech type from vanillaand proper mod prefix
             //high chance of false positives
             } else if (vanillaHullSpecs.contains(baseId) && vanillaTechTypes.contains(techType) && hullSpec.getShipFilePath().matches(prefixRegex)) {
             //do the stuff
             String emptyHullVariantId = id + "_Hull";
             ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
             if (variant.isFighter() || variant.isStation() || blacklistedVariants.contains(emptyHullVariantId)) {
             continue;
             }
             FleetMemberAPI member = Global.getFactory().createFleetMember(FleetMemberType.SHIP, emptyHullVariantId);
             ships.add(member);
             log.info("Skin " + id + " added to mission - condition 3");
             }
             */
        }
        return ships;
    }

    /*
     For the ships that I have literally no clue how else to add a mission.
     These are mod skins of vanilla ships where the manufacturer is not any of the factions added by the mod, nor one used by any of the skins of mod ships
     i.e. 
     */
    /*
     public static Set<FleetMemberAPI> createFleetMembersFromManualFix(
     ArrayList<String> vanillaHullSpecs,
     ArrayList<String> modHullSpecs,
     ArrayList<String> modTechTypes,
     Set<String> blacklistedVariants,
     String prefixRegex,
     ArrayList<String> factionsFromMod) {
     Set<FleetMemberAPI> ships = new HashSet<>();
     */
    /*
     Obtains a list of common prefixes used by a mod
     Converts this list into a regex that can be used with String.matches()
     */
    public static String getCommonPrefixRegex(String modId, int minForCommon) {
        Set<Map.Entry<String, Integer>> sortedPrefixTimesUsed = new TreeSet<>(PRIORITY_MAP);
        Map<String, Integer> unsortedPrefixTimesUsed = new HashMap<>();
        try {

            ArrayList<String> commonPrefixes = new ArrayList<>();
            JSONArray ship_data = Global.getSettings().loadCSV(SHIP_DATA, modId);
            int numRows = ship_data.length();
            for (int i = 0; i < numRows; i++) {
                //String prefix = null;
                JSONObject row = ship_data.getJSONObject(i);
                String id = row.getString("id");
                if (!id.isEmpty()) {
                    String emptyHullVariantId = id + "_Hull";
                    ShipVariantAPI variant = Global.getSettings().getVariant(emptyHullVariantId);
                    if (variant != null && !variant.isFighter()) {
                        String prefix = id.split("_")[0];
                        if (unsortedPrefixTimesUsed.keySet().contains(prefix)) {
                            Integer timesUsed = unsortedPrefixTimesUsed.get(prefix) + 1;
                            unsortedPrefixTimesUsed.put(prefix, timesUsed);
                        } else {
                            unsortedPrefixTimesUsed.put(prefix, 1);
                        }
                    }
                }
            }

            sortedPrefixTimesUsed.addAll(unsortedPrefixTimesUsed.entrySet());
            log.info("Prefixes sorted by usage: " + sortedPrefixTimesUsed);
            for (Map.Entry<String, Integer> entry : sortedPrefixTimesUsed) {
                if (entry.getValue() >= minForCommon) {
                    commonPrefixes.add(entry.getKey());
                }
            }

            //I don't know why it has to be like this but it do
            String filePathStartRegex = "data\\\\\\\\hulls\\\\\\\\skins\\\\\\\\";
            //Format is "(data\\hull\\skins\\<prefix1>|data\\hull\\skins\\<prefix2>|...).*"
            String prefixRegex = "(data\\\\hulls\\\\skins\\\\"
                    + commonPrefixes.toString().substring(1, commonPrefixes.toString().length() - 1).replaceAll(", ", "|" + filePathStartRegex)
                    + ").*";

            return prefixRegex;
        } catch (IOException | JSONException ex) {
            log.info("Error fetching vanilla base hulls");
            return null;
        }
    }

    /*
     Yet another method for finding skins
     */
    public static ArrayList<String> getFactionsFromMod(String modId) {

        ArrayList<String> vanillaFactions = new ArrayList<>();
        vanillaFactions.add(Factions.PLAYER);
        vanillaFactions.add(Factions.NEUTRAL);
        vanillaFactions.add(Factions.MERCENARY);
        vanillaFactions.add(Factions.INDEPENDENT);
        vanillaFactions.add(Factions.SCAVENGERS);
        vanillaFactions.add(Factions.PIRATES);
        vanillaFactions.add(Factions.PERSEAN);
        vanillaFactions.add(Factions.TRITACHYON);
        vanillaFactions.add(Factions.HEGEMONY);
        vanillaFactions.add(Factions.OMEGA);
        vanillaFactions.add(Factions.LIONS_GUARD);
        vanillaFactions.add(Factions.DIKTAT);
        vanillaFactions.add(Factions.KOL);
        vanillaFactions.add(Factions.LUDDIC_CHURCH);
        vanillaFactions.add(Factions.LUDDIC_PATH);
        vanillaFactions.add(Factions.DERELICT);
        vanillaFactions.add(Factions.REMNANTS);
        vanillaFactions.add(Factions.SLEEPER);
        vanillaFactions.add(Factions.POOR);

        ArrayList<String> factionsFromMod = new ArrayList<>();
        //get mods which have a factions.csv
        ArrayList<String> sources = new ArrayList<>();
        try {
            JSONArray array = Global.getSettings().getMergedSpreadsheetDataForMod("faction", FACTION_DATA, "starsector-core");
            int numRows = array.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = array.getJSONObject(i);
                String faction = row.getString("faction");
                if (!faction.isEmpty()) {
                    String source = row.getString("fs_rowSource");
                    if (!sources.contains(source)) {
                        sources.add(source);
                        log.info("Added source: " + source);
                    }
                }
            }
        } catch (IOException | JSONException ex) {
            log.info("Couldn't fetch factions.csv.");
        }

        //get mod name/id given path for all enabled non-utility mods
        ArrayList<String> modsWithFactions = new ArrayList<>();
        List<ModSpecAPI> enabledMods = Global.getSettings().getModManager().getEnabledModsCopy();
        Map<String, String> pathMap = new HashMap<>();

        for (ModSpecAPI mod : enabledMods) {
            if (mod.isUtility()) {
                continue;
            }
            String path = mod.getPath();
            String id = mod.getId();

            pathMap.put(path, id);
        }

        //if a mod has a unique entry in factions.csv, obtain its mod name/id and add it to the list
        for (String source : sources) {
            for (String path : pathMap.keySet()) {
                String modIdOrName = pathMap.get(path);
                if (source.contains(path) && !modsWithFactions.contains(modIdOrName)) {
                    modsWithFactions.add(modIdOrName);
                }
            }
        }

        //if the given modId isn't present (i.e. the mod doesn't add any factions), return
        //else find the factions and faction name
        if (!modsWithFactions.contains(modId)) {
            return factionsFromMod;
        } else {
            try {
                JSONArray factions = Global.getSettings().loadCSV(FACTION_DATA, modId);
                int numRows = factions.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = factions.getJSONObject(i);
                    String factionPath = row.getString("faction");
                    if (!factionPath.isEmpty()) {
                        JSONObject faction = Global.getSettings().loadJSON(factionPath, modId);
                        String name = faction.getString("displayName");
                        if (!vanillaFactions.contains(name)) {
                            factionsFromMod.add(name);
                        }
                    }
                }
            } catch (IOException | JSONException ex) {
                log.info("Couldn't fetch factions.csv for " + modId + ".");
            }
        }

        log.info("Factions from mod " + modId + ": " + factionsFromMod);
        return factionsFromMod;
    }
}
