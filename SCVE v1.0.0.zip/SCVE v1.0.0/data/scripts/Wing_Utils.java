package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.ModSpecAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Wing_Utils {

    public static Logger log = Global.getLogger(Wing_Utils.class);

    public static final String VANILLA_WING_DATA = "data/config/SCVE/wing_data_backup.csv";
    public static final String WING_DATA = "data/hulls/wing_data.csv";
    public static String RESTRICTED = "restricted";
    public static Float OP_TO_DISABLE = 100000f;

    public static HashMap<String, Set<String>> getWingTagsMap() {
        HashMap<String, Set<String>> wingTagsMap = new HashMap<>();
        for (FighterWingSpecAPI w : Global.getSettings().getAllFighterWingSpecs()) {
            Set<String> tags = new HashSet<>();
            tags.addAll(w.getTags());
            wingTagsMap.put(w.getId(), tags);
        }
        return wingTagsMap;
    }

    public static HashMap<String, Float> getWingOPCostMap() {
        HashMap<String, Float> wingsOPCostMap = new HashMap<>();
        for (FighterWingSpecAPI w : Global.getSettings().getAllFighterWingSpecs()) {
            Float OPCost = w.getOpCost(null);
            wingsOPCostMap.put(w.getId(), OPCost);
        }
        return wingsOPCostMap;
    }

    public static void restoreWingTags(HashMap<String, Set<String>> wingTagsMap) {
        log.info("Restoring wing tags...");
        for (String id : wingTagsMap.keySet()) {
            FighterWingSpecAPI wing = Global.getSettings().getFighterWingSpec(id);
            wing.getTags().clear();
            wing.getTags().addAll(wingTagsMap.get(id));
        }
        log.info("Done restoring wing tags.");
    }

    public static void restoreWingOPCosts(HashMap<String, Float> wingOPCostMap) {
        log.info("Restoring wing OP costs...");
        for (String id : wingOPCostMap.keySet()) {
            FighterWingSpecAPI wing = Global.getSettings().getFighterWingSpec(id);
            wing.setOpCost(wingOPCostMap.get(id));
        }
        log.info("Done restoring wing OP costs.");
    }

    /*
     Okay so this is literally the most randomly jank shit ever.
     Whether or not a wing can be placed in a bay is locked-in the
     first time you try to install an LPC. If you add an autofit tag
     to an LPC to have it show on the mission screen, that LPC will
     *always* be placeable in the mission screen, even if the tag is
     removed later. Conversely, if you try to install an LPC before 
     adding an autofit tag, the LPC will *never* be placeable in the
     mission screen, even if the tag is added later.
     Note that this does not apply to the "restricted" tag, though:
     it can be added or removed and functions as you'd expect.
     */
    public static void showRestrictedWings() {
        log.info("Removing restricted tag from wings...");
        for (FighterWingSpecAPI w : Global.getSettings().getAllFighterWingSpecs()) {
            if (w.hasTag(RESTRICTED)) {
                w.getTags().remove(RESTRICTED);
                log.info("Removed restricted tag from wing " + w.getWingName());
            }
            if (!w.getTags().toString().matches(".*(fighter|bomber|interceptor)[0-9].*")) {
                w.getTags().add("fighter0");
                log.info("Adding fighter0 tag to wing " + w.getWingName());
            }
        }
        log.info("Finished removing restricted tag from wings.");
    }

    public static ArrayList<String> getVanillaWings() {
        ArrayList<String> vanillaWings = new ArrayList<>();
        try {
            JSONArray wing_data = Global.getSettings().loadCSV(VANILLA_WING_DATA);
            int numRows = wing_data.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = wing_data.getJSONObject(i);
                String id = row.getString("id");
                String tags = row.getString("tags");
                //filters out non-modular wings
                if (!id.isEmpty()
                        && !tags.contains("no_drop")) {
                    vanillaWings.add(id);
                }
            }
            log.info("List of vanilla wings loaded.");
        } catch (IOException | JSONException ex) {
            log.info("Error fetching vanilla wings.");
        }

        return vanillaWings;
    }

    //add exceptions for SWP?
    public static void hideWingsFromOtherMods(String modId, ArrayList<String> vanillaWings, boolean hideVanilla) {
        log.info("Hiding wings from mods that aren't from " + modId + "...");
        if (hideVanilla) {
            log.info("Also hiding vanilla wings.");
        }
        ArrayList<String> wingsFromMod = new ArrayList<>();
        if (!(modId == null)) {
            wingsFromMod = getWingsFromMod(modId);
        }
        for (FighterWingSpecAPI wing : Global.getSettings().getAllFighterWingSpecs()) {
            String id = wing.getId();
            if (!wingsFromMod.contains(id) && !wing.hasTag(RESTRICTED)) {
                if (!hideVanilla) {
                    if (!vanillaWings.contains(id)) {
                        //wing.addTag(RESTRICTED);
                        wing.setOpCost(OP_TO_DISABLE);
                    }
                } else {
                    //wing.addTag(RESTRICTED);
                    wing.setOpCost(OP_TO_DISABLE);
                }
            }
        }

        log.info(
                "Done hiding wings from other mods.");
    }

    public static ArrayList<String> getWingsFromMod(String modId) {

        ArrayList<String> wingsFromMod = new ArrayList<>();
        //get mods which have a wing_data.csv
        ArrayList<String> sources = new ArrayList<>();
        try {
            JSONArray array = Global.getSettings().getMergedSpreadsheetDataForMod("id", WING_DATA, "starsector-core");
            int numRows = array.length();
            for (int i = 0; i < numRows; i++) {
                JSONObject row = array.getJSONObject(i);
                String id = row.getString("id");
                if (!id.isEmpty()) {
                    String source = row.getString("fs_rowSource");
                    if (!sources.contains(source)) {
                        sources.add(source);
                        //log.info("Added source: " + source);
                    }
                }
            }
        } catch (IOException | JSONException ex) {
            log.info("Couldn't fetch wing_data.csv.");
        }
        //log.info("Wing sources: " + sources);

        //get mod name/id given path for all enabled non-utility mods
        ArrayList<String> modsWithWings = new ArrayList<>();
        List<ModSpecAPI> enabledMods = Global.getSettings().getModManager().getEnabledModsCopy();
        Map<String, String> pathMap = new HashMap<>();

        for (ModSpecAPI mod : enabledMods) {
            if (mod.isUtility()) {
                continue;
            }
            String path = mod.getPath();
            String id = mod.getId();

            pathMap.put(path, id);
        }
        //log.info("Path + Id: " + pathMap);

        //if a mod has a unique entry in wing_data.csv, obtain its mod name/id and add it to the list
        for (String source : sources) {
            for (String path : pathMap.keySet()) {
                String modIdOrName = pathMap.get(path);
                if (source.contains(path) && !modsWithWings.contains(modIdOrName)) {
                    modsWithWings.add(modIdOrName);
                }
            }
        }
        log.info("Mods with wings: " + modsWithWings);

        //if the given modId isn't present (i.e. the mod doesn't add any wing), return
        //else find the wing
        if (!modsWithWings.contains(modId)) {
            return wingsFromMod;
        } else {
            try {
                JSONArray wings = Global.getSettings().loadCSV(WING_DATA, modId);
                int numRows = wings.length();
                for (int i = 0; i < numRows; i++) {
                    JSONObject row = wings.getJSONObject(i);
                    String wingId = row.getString("id");
                    if (!wingId.isEmpty()) {
                        wingsFromMod.add(wingId);
                    }
                }
            } catch (IOException | JSONException ex) {
                log.info("Couldn't fetch wing_data.csv for " + modId + ".");
            }
        }
        log.info("Wings from mod " + modId + ": " + wingsFromMod);
        return wingsFromMod;
    }
}
